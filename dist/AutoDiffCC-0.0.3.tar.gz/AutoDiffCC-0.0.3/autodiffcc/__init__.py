# PyPI Name
name = "autodiffcc"

from .autodiffcc import *
