from autodiffcc import addition


def test_adding():
    assert addition.adding(2, 2) == 4
    

    
    
